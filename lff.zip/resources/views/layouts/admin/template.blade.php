@include('layouts.admin.header')
@include('layouts.admin.sidebar')
<div class="page-content">

        @yield('body')
</div>
@include('layouts.admin.footer')