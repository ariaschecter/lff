@include('layouts.user.header')
@include('layouts.user.topbar')
<div class="page-content">
        @yield('body')
</div>

@include('layouts.user.footer')
