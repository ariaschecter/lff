$(function() {
  'use strict';

  $('#cp1, #cp2, #cp3').colorpicker();
});